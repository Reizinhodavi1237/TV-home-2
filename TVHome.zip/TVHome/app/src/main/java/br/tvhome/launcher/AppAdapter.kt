package br.tvhome.launcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val style: CardStyle,
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    var items: List<AppEntry> = emptyList()
        private set

    fun submit(list: List<AppEntry>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView? = v.findViewById(R.id.label)
        val subtitle: TextView? = v.findViewById(R.id.subtitle)
    }

    // No estilo FEATURED, o primeiro item é o card largo ("hero").
    override fun getItemViewType(position: Int) =
        if (style == CardStyle.FEATURED && position == 0) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = when (style) {
            CardStyle.TILE -> R.layout.item_tile
            CardStyle.CARD -> R.layout.item_app
            CardStyle.FEATURED -> if (viewType == 1) R.layout.item_hero else R.layout.item_small
        }
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        val grow = if (viewType == 1) 1.04f else 1.06f
        // Destaque leve: só escala (barato para a GPU da TV).
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) grow else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        val ctx = holder.itemView.context
        holder.label?.text = e.label
        holder.subtitle?.text = ctx.getString(R.string.recent_sub)
        val banner = style == CardStyle.TILE || (style == CardStyle.FEATURED && position == 0)
        IconLoader.load(ctx, e, holder.icon, banner)
        holder.itemView.setOnClickListener { onClick(e) }
        holder.itemView.setOnLongClickListener {
            onLongClick(e)
            true
        }
    }

    override fun getItemCount() = items.size
}
