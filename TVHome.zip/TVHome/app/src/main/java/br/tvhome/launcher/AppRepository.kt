package br.tvhome.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build

object AppRepository {

    // Heurística: pacotes e palavras-chave comuns de streaming. Ajuste à vontade.
    private val streamingPackages = setOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.hbo.hbonow",
        "com.wbd.stream",
        "com.globo.globotv",
        "com.spotify.tv.android",
        "tv.pluto.android",
        "com.apple.atve.androidtv.appletv"
    )
    private val streamingKeywords = listOf(
        "netflix", "youtube", "primevideo", "amazonvideo", "disney", "hbo",
        "globo", "pluto", "paramount", "appletv", "crunchyroll", "twitch", "plex"
    )

    fun load(context: Context): Map<Section, List<AppEntry>> {
        val pm = context.packageManager
        val seen = HashSet<String>()
        val streaming = ArrayList<AppEntry>()
        val games = ArrayList<AppEntry>()
        val apps = ArrayList<AppEntry>()

        for (category in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName || !seen.add(pkg)) continue
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: continue
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val entry = AppEntry(pkg, ri.loadLabel(pm).toString(), launch, pkg)
                when (sectionFor(pkg, ri.activityInfo.applicationInfo)) {
                    Section.STREAMING -> streaming.add(entry)
                    Section.GAMES -> games.add(entry)
                    else -> apps.add(entry)
                }
            }
        }

        return mapOf(
            Section.STREAMING to streaming.sortedBy { it.label.lowercase() },
            Section.GAMES to games.sortedBy { it.label.lowercase() },
            Section.APPS to apps.sortedBy { it.label.lowercase() }
        )
    }

    private fun sectionFor(pkg: String, info: ApplicationInfo): Section {
        val p = pkg.lowercase()
        if (p in streamingPackages || streamingKeywords.any { p.contains(it) }) return Section.STREAMING
        val byCategory = Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME
        @Suppress("DEPRECATION")
        val byFlag = (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        return if (byCategory || byFlag) Section.GAMES else Section.APPS
    }
}
