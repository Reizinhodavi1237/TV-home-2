package br.tvhome.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewTreeObserver
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {

    private class Row(val view: View, val list: RecyclerView, val adapter: AppAdapter)

    private enum class Tab(val title: String) {
        HOME("Início"), STREAMING("Streaming"), GAMES("Jogos"), APPS("Aplicativos")
    }

    private lateinit var favorites: Favorites
    private lateinit var recents: Recents
    private lateinit var scroll: ScrollView
    private val rows = LinkedHashMap<Section, Row>()
    private val tabViews = LinkedHashMap<Tab, TextView>()
    private var tab = Tab.HOME
    private var data: Map<Section, List<AppEntry>> = emptyMap()
    private var firstLoad = true

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        favorites = Favorites(this)
        recents = Recents(this)
        scroll = findViewById(R.id.scroll)

        bindShortcut(R.id.btnWifi, Settings.ACTION_WIFI_SETTINGS)
        bindShortcut(R.id.btnBluetooth, Settings.ACTION_BLUETOOTH_SETTINGS)
        bindShortcut(R.id.btnSettings, Settings.ACTION_SETTINGS)

        // Abas
        val tabsBox = findViewById<LinearLayout>(R.id.tabs)
        for (t in Tab.values()) {
            val tv = TextView(this)
            tv.text = t.title
            tv.textSize = 20f
            tv.setTextColor(Color.WHITE)
            tv.setPadding(dp(18), dp(8), dp(18), dp(8))
            tv.isFocusable = true
            tv.isClickable = true
            tv.setBackgroundResource(R.drawable.tab_bg)
            tv.setOnFocusChangeListener { _, has -> if (has) selectTab(t) }
            tv.setOnClickListener { selectTab(t) }
            tabsBox.addView(tv)
            tabViews[t] = tv
        }

        // Linhas de conteúdo
        val container = findViewById<LinearLayout>(R.id.container)
        val inflater = LayoutInflater.from(this)
        for (section in Section.values()) {
            val view = inflater.inflate(R.layout.section_row, container, false)
            val title = view.findViewById<TextView>(R.id.title)
            val list = view.findViewById<RecyclerView>(R.id.list)
            if (section.title.isEmpty()) {
                title.visibility = View.GONE
                view.setPadding(0, dp(24), 0, 0)
            } else {
                title.text = section.title
            }
            if (section == Section.FAVORITES) {
                list.setBackgroundResource(R.drawable.dock_bg)
                list.setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            list.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            list.itemAnimator = null
            val adapter = AppAdapter(
                style = section.style,
                onClick = { launch(it) },
                onLongClick = { toggleFavorite(it, section) }
            )
            list.adapter = adapter
            view.visibility = View.GONE
            container.addView(view)
            rows[section] = Row(view, list, adapter)
        }
        selectTab(Tab.HOME)
    }

    override fun onResume() {
        super.onResume()
        // Recarrega a lista (apps novos aparecem) fora da thread principal.
        Thread {
            val loaded = AppRepository.load(this)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                data = loaded
                favorites.seedIfNeeded(loaded[Section.STREAMING].orEmpty().take(7).map { it.id })
                render()
                if (firstLoad) {
                    firstLoad = false
                    afterLayout { firstCard()?.requestFocus() }
                }
            }
        }.start()
    }

    private fun selectTab(t: Tab) {
        tab = t
        for ((k, v) in tabViews) {
            v.alpha = if (k == t) 1f else 0.55f
            v.typeface = if (k == t) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        render()
    }

    private fun visibleIn(section: Section) = when (section) {
        Section.RECENT -> tab == Tab.HOME
        Section.FAVORITES -> true
        Section.STREAMING -> tab == Tab.HOME || tab == Tab.STREAMING
        Section.GAMES -> tab == Tab.HOME || tab == Tab.GAMES
        Section.APPS -> tab == Tab.HOME || tab == Tab.APPS
    }

    private fun render() {
        val byId = data.values.flatten().associateBy { it.id }
        val lists: Map<Section, List<AppEntry>> = mapOf(
            Section.RECENT to recents.list().mapNotNull { byId[it] }.take(6),
            Section.FAVORITES to favorites.all().mapNotNull { byId[it] }
        ) + data
        for ((section, row) in rows) {
            val list = lists[section].orEmpty()
            row.view.visibility = if (list.isNotEmpty() && visibleIn(section)) View.VISIBLE else View.GONE
            // Só atualiza se mudou, para não perder o foco à toa.
            if (row.adapter.items.map { it.id } != list.map { it.id }) row.adapter.submit(list)
        }
    }

    private fun bindShortcut(viewId: Int, action: String) {
        findViewById<View>(viewId).setOnClickListener {
            launchIntent(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun launch(entry: AppEntry) {
        recents.push(entry.id)
        launchIntent(entry.intent)
    }

    private fun launchIntent(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Não disponível nesta TV")
        } catch (e: SecurityException) {
            toast("Não disponível nesta TV")
        }
    }

    /** OK longo (segurar o botão OK) adiciona/remove da dock de favoritos. */
    private fun toggleFavorite(entry: AppEntry, origin: Section) {
        val oldIndex = rows[origin]?.adapter?.items?.indexOfFirst { it.id == entry.id } ?: -1
        val added = favorites.toggle(entry.id)
        toast(if (added) "Adicionado aos favoritos" else "Removido dos favoritos")
        render()
        // Só a linha de favoritos muda de posição quando se mexe nela.
        if (origin == Section.FAVORITES) {
            val row = rows[Section.FAVORITES] ?: return
            afterLayout {
                val size = row.adapter.items.size
                val target = if (size > 0 && oldIndex >= 0) {
                    row.list.findViewHolderForAdapterPosition(minOf(oldIndex, size - 1))?.itemView
                } else null
                if (target == null || !target.requestFocus()) firstCard()?.requestFocus()
            }
        }
    }

    private fun firstCard(): View? {
        for (row in rows.values) {
            if (row.view.visibility != View.VISIBLE) continue
            val v = row.list.findViewHolderForAdapterPosition(0)?.itemView ?: row.list.getChildAt(0)
            if (v != null) return v
        }
        return null
    }

    /** Executa uma vez, depois da próxima passada de layout. */
    private fun afterLayout(block: () -> Unit) {
        scroll.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                scroll.viewTreeObserver.removeOnGlobalLayoutListener(this)
                block()
            }
        })
    }

    /** Voltar leva à aba "Início" no topo; não fecha o launcher. */
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val home = tabViews[Tab.HOME]
        if (home != null && currentFocus !== home) {
            scroll.smoothScrollTo(0, 0)
            home.requestFocus()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
