# TV Home — launcher para Android TV (TCL)

Visual: fundo #080808, cards com borda branca, navegação 100% por controle remoto.
Sem blur, sem imagens grandes: ícones reduzidos a 144px com cache e carregamento em segundo plano.
Código 100% Kotlin/Java (sem bibliotecas nativas), então roda em ARMv7 de 32 bits.

## Estrutura
```
TVHome/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts            (minSdk 21, só RecyclerView como dependência)
    └── src/main/
        ├── AndroidManifest.xml     (LEANBACK_LAUNCHER + tentativa de HOME)
        ├── java/br/tvhome/launcher/
        │   ├── MainActivity.kt     (abas, linhas, foco, Voltar, favoritos)
        │   ├── AppRepository.kt    (lista apps e classifica)
        │   ├── AppAdapter.kt       (cards, tiles da dock e cards de destaque)
        │   ├── IconLoader.kt       (banner/ícone leve com cache)
        │   ├── Favorites.kt        (favoritos e recentes)
        │   └── AppEntry.kt
        └── res/ (layouts, cores, cards, ícones vetoriais)
```

## Compilar
1. Instale o Android Studio (versão recente, com JDK 17).
2. File > Open e escolha a pasta `TVHome`. Aguarde o Gradle sincronizar (precisa de internet).
3. Build > Build APK(s). O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.
   (Ou no terminal: `./gradlew assembleDebug`, depois de o Android Studio gerar o wrapper.)

## Instalar na TV
Opção A, pendrive: copie o APK, abra no gerenciador de arquivos da TV e instale (permita "Fontes desconhecidas" para esse app quando pedir).
Opção B, ADB pela rede: ative as Opções do desenvolvedor (toque 7x em "Compilação") e a depuração USB/ADB; descubra o IP da TV e rode:
```
adb connect IP_DA_TV:5555
adb install -r app-debug.apk
```

## Como usar
Layout inspirado na imagem de referência (tema escuro, como pedido):
- Topo: relógio e data à esquerda; botões redondos de Wi-Fi, Bluetooth e Configurações à direita.
- Abas: Início, Streaming, Jogos, Aplicativos (basta focar a aba para trocá-la).
- "Continuar": o primeiro card é largo (mostra o banner do app, se ele tiver um) e os seguintes são estreitos. São os últimos apps que você abriu pelo launcher.
- Dock de favoritos: faixa arredondada com os apps em formato de banner. Na primeira execução ela é preenchida com os apps de streaming encontrados.
- Abaixo: linhas Streaming, Jogos e Aplicativos.
- Setas navegam, OK abre, segurar OK adiciona/remove da dock. Voltar leva à aba Início.

## Testar
1. Abra "TV Home" na lista de apps da TV.
2. Confira relógio/data, setas em todas as direções e foco branco bem visível.
3. Segure OK em um app: ele entra (ou sai) da dock de favoritos.
4. Abra um app e use Voltar/Home para retornar.
5. Teste os três botões redondos do topo (Wi-Fi, Bluetooth, Configurações).
6. Aperte Home: veja se a TV pergunta qual tela inicial usar.

## Limitações
- Substituir a tela inicial original depende da TCL. O app se oferece como HOME, mas muitos fabricantes ignoram ou travam isso; só testando na sua TV. Se não der, ele funciona como app independente.
- A linha "Continuar" mostra apps usados recentemente, não recomendações de filmes ou séries: o Android TV não oferece a launchers de terceiros um jeito simples de ler o conteúdo dos outros apps.
- Os cartazes e o ticker de cotações da imagem de referência não foram feitos.
- A imagem de referência é clara; mantive fundo #080808 e bordas brancas como você pediu. Dá para criar uma versão clara.
- A classificação em Streaming/Jogos é heurística (nome do pacote e categoria do app); alguns apps podem cair em "Aplicativos". Edite as listas em `AppRepository.kt`.
- Atalhos de Configurações dependem do que a TCL implementa; se um não existir, aparece "Não disponível nesta TV".
- Este projeto foi escrito sem poder compilar no ambiente do Claude. Se o Gradle apontar erro, me mande a mensagem completa.
- Não confirmei RAM/processador da TV; por isso o foco foi manter tudo leve.
