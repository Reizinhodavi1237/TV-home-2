# TV Home v2: launcher para Android TV (TCL)

App nativo em Kotlin (Views + RecyclerView). Sem bibliotecas nativas: roda no ARMv7 de 32 bits.
minSdk 21, targetSdk 34. Única dependência: androidx.recyclerview.

## O que mudou na v2 (diagnóstico e correções)

| Problema | Causa encontrada | Correção |
|---|---|---|
| Botão Home não abria o TV Home | A v1 declarava HOME, mas o Android TV não entrega a tecla Home a um app que o usuário não definiu como padrão; depois eu tirei o filtro HOME para você não ficar preso | Filtros MAIN+HOME+DEFAULT de volta, mais um botão "interface original" (ícone de casa no topo) e Voltar que não prende |
| Alguns botões não funcionavam | O app só tratava setas, OK e Voltar | Menu (≡) favorita o item focado; CH+/CH- trocam de aba; tecla de engrenagem abre Configurações (se a TV entregar) |
| Relógio adiantado | O código usa TextClock com a hora local do sistema, sem conversão manual. Nenhuma soma de horas foi encontrada | Mantido. A diferença vem da hora da própria TV (ver "Relógio") |
| "Continuar" mostrando copyDataToTV | Qualquer app aberto entrava no histórico, inclusive ferramentas | Renomeado para "Abertos recentemente"; ferramentas e apps de sistema não entram; registros inválidos antigos são apagados ao abrir |
| Cartões cortados e imagens ruins | Tamanhos fixos em dp, recorte único e arredondamento que a TCL não aplicou | Tamanhos proporcionais à largura da tela, margem de segurança de 5%, banner inteiro com cantos arredondados desenhados no próprio componente |
| Categorias misturadas | Categoria por trecho do nome | Pacote exato conhecido, categoria declarada pelo app (Android 8+), jogo, e nova seção "Sistema e ferramentas" |

## Arquivos alterados
AndroidManifest.xml, build.gradle.kts (chave fixa), MainActivity.kt, AppAdapter.kt, AppRepository.kt,
IconLoader.kt, Favorites.kt (Recents), AppEntry.kt, Dimens.kt (novo), RoundedImageView.kt,
layouts (activity_main, section_row, item_*), ids.xml, ic_home.xml.
A versão anterior está no arquivo TVHome-versao-anterior.zip.

## Controle remoto (TCL)
| Tecla | O que o TV Home faz |
|---|---|
| Setas / OK | Navegar / abrir. Segurar OK também favorita |
| Voltar | Vai à aba Início; estando nela, fecha o app (ou não faz nada se ele for a tela inicial) |
| Menu (≡) | Favorita ou desfavorita o item selecionado |
| CH+ / CH- | Próxima / aba anterior |
| Engrenagem | Abre Configurações, se a TV entregar a tecla ao app |
| Volume | Não é alterado |
| Home, Entrada, Assistente, Netflix, Globoplay, teclado | Reservadas ao sistema ou ao fabricante. Um app comum não consegue interceptar |

## Tela inicial padrão
O manifesto declara o TV Home como candidato a launcher, mas só o sistema decide se o oferece.
O Android TV não tem um menu padrão para escolher a tela inicial, e muitas TVs da TCL sempre usam a delas.
Não use root nem desative apps do sistema. Para voltar ao original:
1. Botão de casa no canto superior direito do TV Home abre a interface original; ou
2. Configurações > Aplicativos > TV Home > "Limpar padrões" (se existir); ou
3. Desinstalar o TV Home.

## Relógio
O TextClock usa a hora e o fuso do sistema (formato 24 h) e acompanha mudanças de hora, fuso e retorno da suspensão.
Se o horário estiver errado, compare com Configurações > Preferências do dispositivo > Data e hora e use
data/hora automáticas e o fuso correto (Brasília).

## Abertos recentemente
O Android não entrega ao launcher o que você assistiu dentro de Netflix, YouTube etc.
Por isso a seção só lista apps abertos pelo TV Home, e nunca mostra filmes, episódios ou progresso.
Apps abertos por outros meios não aparecem.

## Compilar
GitHub Actions (como você fez): substitua o TVHome.zip do repositório pelo novo e rode "Build APK" em Actions.
Local: Android Studio > Open `TVHome` > Build > Build APK(s), ou `gradle assembleDebug`.
O APK sai assinado com uma chave fixa (app/tvhome.jks, não secreta), então as próximas versões instalam por cima.
Na primeira vez da v2, desinstale o TV Home antigo, que foi assinado com outra chave.

## Verificado no desenvolvimento / precisa testar na TV
Verificado (análise estática): XML válido, todas as referências de recursos e classes existem, chaves balanceadas,
manifesto com MAIN/LEANBACK_LAUNCHER/HOME/DEFAULT, nenhuma conta manual de hora no código.
Não verificado: compilação (este ambiente não tem SDK Android nem internet; o GitHub Actions é o teste real),
comportamento do botão Home, teclas do controle, aparência e desempenho na TCL.
