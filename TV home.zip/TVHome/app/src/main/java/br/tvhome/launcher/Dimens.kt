package br.tvhome.launcher

import android.content.Context

/**
 * Tamanhos proporcionais à largura real da tela. Assim o layout se ajusta
 * à resolução da TV em vez de depender de valores fixos em dp.
 */
class Dimens(context: Context) {
    private val u = context.resources.displayMetrics.widthPixels / 100f

    val heroW = (30f * u).toInt()
    val heroH = heroW * 9 / 16
    val smallW = (11.5f * u).toInt()
    val tileW = (11f * u).toInt()
    val tileH = tileW * 9 / 16
    val cardW = (13.5f * u).toInt()
    val cardH = (cardW * 0.74f).toInt()
    val icon = (5.2f * u).toInt()
    val margin = (0.7f * u).toInt()

    // Margem de segurança (muitas TVs cortam as bordas da imagem)
    val safeX = (5f * u).toInt()
    val safeY = (4f * u).toInt()

    /** Converte "unidades de largura" em pixels (para tamanhos de texto). */
    fun px(units: Float): Float = units * u
}
