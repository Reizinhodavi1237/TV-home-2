package br.tvhome.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors

/**
 * Carrega banner (16:9) ou ícone do app em segundo plano, em tamanho reduzido,
 * com cache em memória. Se o app não tiver banner, usa o ícone.
 */
object IconLoader {
    private const val ICON = 144
    private const val BANNER_W = 320
    private const val BANNER_H = 180

    private class Loaded(val bmp: Bitmap, val banner: Boolean)

    private val cache = LruCache<String, Loaded>(40)
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun trim() = cache.evictAll()

    fun load(context: Context, entry: AppEntry, view: ImageView, preferBanner: Boolean) {
        val key = entry.id + if (preferBanner) "#b" else "#i"
        view.tag = key
        val cached = cache.get(key)
        if (cached != null) {
            show(view, cached)
            return
        }
        view.setImageDrawable(null)
        val pm = context.applicationContext.packageManager
        val pkg = entry.packageName
        executor.execute {
            val loaded = try {
                val banner = if (preferBanner) pm.getApplicationBanner(pkg) else null
                if (banner != null) Loaded(toBitmap(banner, BANNER_W, BANNER_H), true)
                else Loaded(toBitmap(pm.getApplicationIcon(pkg), ICON, ICON), false)
            } catch (e: Exception) {
                null
            }
            if (loaded != null) {
                cache.put(key, loaded)
                main.post { if (view.tag == key) show(view, loaded) }
            }
        }
    }

    private fun show(view: ImageView, l: Loaded) {
        if (l.banner) {
            // Banner inteiro, sem cortar nada (o card tem a mesma proporção 16:9).
            view.scaleType = ImageView.ScaleType.FIT_XY
            view.setPadding(0, 0, 0, 0)
        } else {
            // Ícone quadrado: mantém a proporção e dá respiro nos cards grandes.
            view.scaleType = ImageView.ScaleType.FIT_CENTER
            val big = view.layoutParams.width <= 0
            val pad = if (big) (18 * view.resources.displayMetrics.density).toInt() else 0
            view.setPadding(pad, pad, pad, pad)
        }
        view.setImageBitmap(l.bmp)
    }

    private fun toBitmap(d: Drawable, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, w, h)
        d.draw(Canvas(bmp))
        return bmp
    }
}
