package br.tvhome.launcher

import android.content.Intent

enum class CardStyle { FEATURED, TILE, CARD }

enum class Section(val title: String, val style: CardStyle) {
    RECENT("Abertos recentemente", CardStyle.FEATURED),
    FAVORITES("", CardStyle.TILE),            // dock de favoritos, sem título
    STREAMING("Streaming", CardStyle.CARD),
    GAMES("Jogos", CardStyle.CARD),
    APPS("Aplicativos", CardStyle.CARD),
    SYSTEM("Sistema e ferramentas", CardStyle.CARD)
}

data class AppEntry(
    val id: String,              // nome do pacote
    val label: String,
    val intent: Intent,
    val packageName: String
)
