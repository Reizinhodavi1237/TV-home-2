package br.tvhome.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Build

object AppRepository {

    // Pacotes conhecidos (comparação exata, não por trecho do nome).
    private val streamingPackages = setOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.hbo.hbonow",
        "com.wbd.stream",
        "com.globo.globotv",
        "com.spotify.tv.android",
        "tv.pluto.android",
        "com.apple.atve.androidtv.appletv"
    )

    // Entradas técnicas que nunca devem aparecer como entretenimento.
    private val technicalHints = listOf(
        "copydata", "packageinstaller", "setupwizard", "provision", "factorytest"
    )

    /** Retorna STREAMING, GAMES, APPS e SYSTEM (ferramentas e apps de sistema). */
    fun load(context: Context): Map<Section, List<AppEntry>> {
        val pm = context.packageManager
        val seen = HashSet<String>()
        val result = HashMap<Section, MutableList<AppEntry>>()
        for (s in arrayOf(Section.STREAMING, Section.GAMES, Section.APPS, Section.SYSTEM)) {
            result[s] = ArrayList()
        }

        for (category in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName || !seen.add(pkg)) continue
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: continue   // sem como iniciar: não aparece
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val label = ri.loadLabel(pm).toString()
                val entry = AppEntry(pkg, label, launch, pkg)
                result.getValue(sectionFor(pkg, label, ri.activityInfo.applicationInfo)).add(entry)
            }
        }

        return result.mapValues { (_, list) -> list.sortedBy { it.label.lowercase() } }
    }

    private fun sectionFor(pkg: String, label: String, info: ApplicationInfo): Section {
        val p = pkg.lowercase()
        val l = label.lowercase()

        // 1) Entradas técnicas
        if (technicalHints.any { p.contains(it) || l.contains(it) }) return Section.SYSTEM

        // 2) Categoria declarada pelo próprio app (Android 8+) ou pacote conhecido
        val cat = if (Build.VERSION.SDK_INT >= 26) info.category else -1
        if (pkg in streamingPackages) return Section.STREAMING
        if (Build.VERSION.SDK_INT >= 26 &&
            (cat == ApplicationInfo.CATEGORY_VIDEO || cat == ApplicationInfo.CATEGORY_AUDIO)
        ) return Section.STREAMING

        // 3) Jogos
        @Suppress("DEPRECATION")
        val flagGame = (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        if ((Build.VERSION.SDK_INT >= 26 && cat == ApplicationInfo.CATEGORY_GAME) || flagGame) {
            return Section.GAMES
        }

        // 4) Apps de sistema que não foram atualizados pelo usuário
        val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val isUpdated = (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        if (isSystem && !isUpdated) return Section.SYSTEM

        return Section.APPS
    }
}
