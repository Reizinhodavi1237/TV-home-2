package br.tvhome.launcher

import android.content.Context

/** Lista ordenada de ids guardada em SharedPreferences. */
private fun readList(raw: String?): List<String> =
    (raw ?: "").split("|").filter { it.isNotEmpty() }

class Favorites(context: Context) {
    private val prefs = context.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    fun all(): List<String> = readList(prefs.getString(KEY, ""))

    /** Retorna true se o item passou a ser favorito. */
    fun toggle(id: String): Boolean {
        val list = all().toMutableList()
        val added = if (list.remove(id)) false else { list.add(id); true }
        save(list)
        return added
    }

    /** Na primeira execução, preenche a dock com apps de streaming encontrados. */
    fun seedIfNeeded(ids: List<String>) {
        if (prefs.getBoolean(SEEDED, false) || ids.isEmpty()) return
        save(ids)
        prefs.edit().putBoolean(SEEDED, true).apply()
    }

    private fun save(list: List<String>) {
        prefs.edit().putString(KEY, list.joinToString("|")).apply()
    }

    private companion object {
        const val KEY = "ids"
        const val SEEDED = "seeded"
    }
}

/**
 * Apps abertos recentemente pelo TV Home. Não é histórico de reprodução:
 * o Android não entrega ao launcher o que foi assistido dentro de cada app.
 */
class Recents(context: Context) {
    private val prefs = context.getSharedPreferences("recents", Context.MODE_PRIVATE)

    fun list(): List<String> = readList(prefs.getString(KEY, ""))

    fun push(id: String) {
        val list = list().toMutableList()
        list.remove(id)
        list.add(0, id)
        save(list.take(MAX))
    }

    /** Remove registros que não são mais válidos (ex.: ferramentas do sistema). */
    fun retain(validIds: Set<String>) {
        val current = list()
        val kept = current.filter { it in validIds }
        if (kept.size != current.size) save(kept)
    }

    private fun save(list: List<String>) {
        prefs.edit().putString(KEY, list.joinToString("|")).apply()
    }

    private companion object {
        const val KEY = "ids"
        const val MAX = 8
    }
}
