package br.tvhome.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewTreeObserver
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private class Row(val view: View, val list: RecyclerView, val adapter: AppAdapter)

    private enum class Tab(val title: String) {
        HOME("Início"), STREAMING("Streaming"), GAMES("Jogos"), APPS("Aplicativos")
    }

    private lateinit var dimens: Dimens
    private lateinit var favorites: Favorites
    private lateinit var recents: Recents
    private lateinit var scroll: ScrollView
    private val rows = LinkedHashMap<Section, Row>()
    private val tabViews = LinkedHashMap<Tab, TextView>()
    private var tab = Tab.HOME
    private var data: Map<Section, List<AppEntry>> = emptyMap()
    private var nonSystemIds: Set<String> = emptySet()
    private val loading = AtomicBoolean(false)
    private var launchedAsHome = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun TextView.setPx(units: Float) =
        setTextSize(TypedValue.COMPLEX_UNIT_PX, dimens.px(units))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dimens = Dimens(this)
        favorites = Favorites(this)
        recents = Recents(this)
        launchedAsHome = intent.hasCategory(Intent.CATEGORY_HOME)
        scroll = findViewById(R.id.scroll)
        scroll.setPadding(dimens.safeX, dimens.safeY, dimens.safeX, dimens.safeY)

        // O relógio usa a hora local do sistema (TextClock), sem nenhum ajuste manual.
        findViewById<TextClock>(R.id.clock).setPx(4.4f)
        findViewById<TextClock>(R.id.date).setPx(1.7f)

        findViewById<View>(R.id.btnOriginal).setOnClickListener { openSystemHome() }
        bindShortcut(R.id.btnWifi, Settings.ACTION_WIFI_SETTINGS)
        bindShortcut(R.id.btnBluetooth, Settings.ACTION_BLUETOOTH_SETTINGS)
        bindShortcut(R.id.btnSettings, Settings.ACTION_SETTINGS)

        // Abas
        val tabsBox = findViewById<LinearLayout>(R.id.tabs)
        for (t in Tab.values()) {
            val tv = TextView(this)
            tv.text = t.title
            tv.setPx(1.7f)
            tv.setTextColor(Color.WHITE)
            tv.setPadding(dp(18), dp(8), dp(18), dp(8))
            tv.isFocusable = true
            tv.isClickable = true
            tv.setBackgroundResource(R.drawable.tab_bg)
            tv.setOnFocusChangeListener { _, has -> if (has) selectTab(t) }
            tv.setOnClickListener { selectTab(t) }
            tabsBox.addView(tv)
            tabViews[t] = tv
        }

        // Linhas de conteúdo
        val container = findViewById<LinearLayout>(R.id.container)
        val inflater = LayoutInflater.from(this)
        for (section in Section.values()) {
            val view = inflater.inflate(R.layout.section_row, container, false)
            val title = view.findViewById<TextView>(R.id.title)
            val list = view.findViewById<RecyclerView>(R.id.list)
            if (section.title.isEmpty()) {
                title.visibility = View.GONE
                view.setPadding(0, dp(20), 0, 0)
            } else {
                title.text = section.title
                title.setPx(1.8f)
            }
            if (section == Section.FAVORITES) {
                list.setBackgroundResource(R.drawable.dock_bg)
                list.setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            list.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            list.itemAnimator = null
            val adapter = AppAdapter(
                section = section,
                dimens = dimens,
                onClick = { launch(it) },
                onLongClick = { toggleFavorite(it, section) }
            )
            list.adapter = adapter
            view.visibility = View.GONE
            container.addView(view)
            rows[section] = Row(view, list, adapter)
        }
        selectTab(Tab.HOME)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launchedAsHome = intent.hasCategory(Intent.CATEGORY_HOME)
        // Voltou ao launcher (ex.: botão Home): começa do topo.
        goToTop()
    }

    override fun onResume() {
        super.onResume()
        // Recarrega a lista (apps novos aparecem) fora da thread principal, sem sobreposição.
        if (!loading.compareAndSet(false, true)) return
        Thread {
            val loaded = try {
                AppRepository.load(this)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                loading.set(false)
                if (isFinishing || loaded == null) return@runOnUiThread
                data = loaded
                nonSystemIds = loaded
                    .filterKeys { it != Section.SYSTEM }
                    .values.flatten().map { it.id }.toSet()
                favorites.seedIfNeeded(loaded[Section.STREAMING].orEmpty().take(7).map { it.id })
                recents.retain(nonSystemIds)   // limpa registros inválidos
                render()
                ensureFocus()
            }
        }.start()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) IconLoader.trim()
    }

    // ---------------- Abas e linhas ----------------

    private fun selectTab(t: Tab) {
        tab = t
        for ((k, v) in tabViews) {
            v.alpha = if (k == t) 1f else 0.55f
            v.typeface = if (k == t) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        render()
    }

    private fun visibleIn(section: Section) = when (section) {
        Section.RECENT -> tab == Tab.HOME
        Section.FAVORITES -> true
        Section.STREAMING -> tab == Tab.HOME || tab == Tab.STREAMING
        Section.GAMES -> tab == Tab.HOME || tab == Tab.GAMES
        Section.APPS -> tab == Tab.HOME || tab == Tab.APPS
        Section.SYSTEM -> tab == Tab.APPS
    }

    private fun render() {
        val byId = data.values.flatten().associateBy { it.id }
        val lists: Map<Section, List<AppEntry>> = mapOf(
            Section.RECENT to recents.list()
                .filter { it in nonSystemIds }
                .mapNotNull { byId[it] }.take(6),
            Section.FAVORITES to favorites.all().mapNotNull { byId[it] }
        ) + data
        for ((section, row) in rows) {
            val list = lists[section].orEmpty()
            row.view.visibility = if (list.isNotEmpty() && visibleIn(section)) View.VISIBLE else View.GONE
            // Só atualiza se mudou, para não perder o foco à toa.
            if (row.adapter.items.map { it.id } != list.map { it.id }) row.adapter.submit(list)
        }
    }

    // ---------------- Ações ----------------

    private fun bindShortcut(viewId: Int, action: String) {
        findViewById<View>(viewId).setOnClickListener { openSettings(action) }
    }

    private fun openSettings(action: String) =
        launchIntent(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun launch(entry: AppEntry) {
        // Só apps de verdade entram em "Abertos recentemente"; ferramentas do sistema não.
        if (entry.id in nonSystemIds) recents.push(entry.id)
        launchIntent(entry.intent)
    }

    private fun launchIntent(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Não disponível nesta TV")
        } catch (e: SecurityException) {
            toast("Não disponível nesta TV")
        }
    }

    /** Abre a tela inicial original da TV (outro app que declare HOME), se existir. */
    private fun openSystemHome() {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val other = packageManager.queryIntentActivities(query, 0)
            .firstOrNull { it.activityInfo.packageName != packageName }
        if (other == null) {
            toast("Interface original não encontrada")
            return
        }
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .setComponent(ComponentName(other.activityInfo.packageName, other.activityInfo.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchIntent(i)
    }

    /** Adiciona/remove da dock de favoritos. */
    private fun toggleFavorite(entry: AppEntry, origin: Section) {
        val oldIndex = rows[origin]?.adapter?.items?.indexOfFirst { it.id == entry.id } ?: -1
        val added = favorites.toggle(entry.id)
        toast(if (added) "Adicionado aos favoritos" else "Removido dos favoritos")
        render()
        // Só a linha de favoritos muda de posição quando se mexe nela.
        if (origin == Section.FAVORITES) {
            val row = rows[Section.FAVORITES] ?: return
            afterLayout {
                val size = row.adapter.items.size
                val target = if (size > 0 && oldIndex >= 0) {
                    row.list.findViewHolderForAdapterPosition(minOf(oldIndex, size - 1))?.itemView
                } else null
                if (target == null || !target.requestFocus()) (firstCard() ?: tabViews[Tab.HOME])?.requestFocus()
            }
        }
    }

    // ---------------- Foco ----------------

    private fun firstCard(): View? {
        for (row in rows.values) {
            if (row.view.visibility != View.VISIBLE) continue
            val v = row.list.findViewHolderForAdapterPosition(0)?.itemView ?: row.list.getChildAt(0)
            if (v != null) return v
        }
        return null
    }

    /** Evita foco perdido: se nada estiver focado após o layout, foca o primeiro item. */
    private fun ensureFocus() {
        afterLayout {
            if (currentFocus == null) (firstCard() ?: tabViews[Tab.HOME])?.requestFocus()
        }
    }

    private fun goToTop() {
        scroll.smoothScrollTo(0, 0)
        tabViews[Tab.HOME]?.requestFocus()
    }

    /** Executa uma vez, depois da próxima passada de layout. */
    private fun afterLayout(block: () -> Unit) {
        scroll.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                scroll.viewTreeObserver.removeOnGlobalLayoutListener(this)
                block()
            }
        })
    }

    // ---------------- Controle remoto ----------------

    /**
     * Teclas tratadas aqui (as demais seguem o comportamento normal do Android):
     *  - MENU (≡): adiciona/remove o item focado dos favoritos
     *  - CH+ / CH-: troca de aba
     *  - SETTINGS (engrenagem): abre as configurações, se a TV entregar a tecla ao app
     * HOME, ENTRADA e ASSISTENTE são reservadas ao sistema e podem não chegar ao app.
     * Setas, OK, Voltar e volume não são alterados.
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (event.repeatCount == 0) {
            when (keyCode) {
                KeyEvent.KEYCODE_MENU -> {
                    val v = currentFocus
                    val entry = v?.getTag(R.id.tag_entry) as? AppEntry
                    val section = v?.getTag(R.id.tag_section) as? Section
                    if (entry != null && section != null) toggleFavorite(entry, section)
                    else toast("Selecione um app e aperte Menu para favoritar")
                    return true
                }
                KeyEvent.KEYCODE_CHANNEL_UP -> { switchTab(+1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { switchTab(-1); return true }
                KeyEvent.KEYCODE_SETTINGS -> { openSettings(Settings.ACTION_SETTINGS); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun switchTab(delta: Int) {
        val tabs = Tab.values()
        val t = tabs[(tab.ordinal + delta + tabs.size) % tabs.size]
        selectTab(t)
        tabViews[t]?.requestFocus()
    }

    /**
     * Voltar: primeiro leva à aba "Início". Já nela:
     *  - se o app foi aberto como tela inicial, não faz nada (é a "casa");
     *  - se foi aberto pela lista de apps, fecha e volta para onde estava.
     */
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val home = tabViews[Tab.HOME]
        if (home != null && currentFocus !== home) {
            goToTop()
        } else if (!launchedAsHome) {
            finish()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
