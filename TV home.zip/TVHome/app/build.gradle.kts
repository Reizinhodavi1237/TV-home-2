plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.tvhome.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "br.tvhome.launcher"
        minSdk = 21
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    // Chave fixa de sideload: atualizações instalam por cima sem desinstalar.
    // (Não é uma chave secreta; serve só para instalar direto na TV.)
    signingConfigs {
        create("tvhome") {
            storeFile = file("tvhome.jks")
            storePassword = "android"
            keyAlias = "tvhome"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("tvhome")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tvhome")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
